Primeira linha: n g
  n = número de vértices
  g = número de grupos

Segunda linha: L1 U1 L2 U2 ... Lg UG
  Li = limite inferior do grupo i
  Ui = limite superior do grupo i

Terceira linha: p1 p2 ... pn
  pi = peso do vértice i

Demais linhas: u v d
  u = vértice origem
  v = vértice destino
  d = valor d_uv
